﻿namespace seminar_10.Entitites
{
    public interface IComparible<T>
    {
    }
}